﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dental_clinic_automation
{
    interface IObject
    {
        public void Add(int i) { }
        public void Remove(int i) { }
    }
}
