﻿namespace Dental_clinic_automation
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.panelPatientSave = new System.Windows.Forms.Panel();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.panelServiceSave = new System.Windows.Forms.Panel();
            this.button3 = new System.Windows.Forms.Button();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.panelDoctorSave = new System.Windows.Forms.Panel();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.button4 = new System.Windows.Forms.Button();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox46 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox45 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.panelMakeAnAppointment = new System.Windows.Forms.Panel();
            this.textBox43 = new System.Windows.Forms.TextBox();
            this.button6 = new System.Windows.Forms.Button();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.button5 = new System.Windows.Forms.Button();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.textBox40 = new System.Windows.Forms.TextBox();
            this.textBox39 = new System.Windows.Forms.TextBox();
            this.comboBoxService = new System.Windows.Forms.ComboBox();
            this.textBox38 = new System.Windows.Forms.TextBox();
            this.comboBoxDoctor = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.comboBoxPatient = new System.Windows.Forms.ComboBox();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.panelPatientSave.SuspendLayout();
            this.panelServiceSave.SuspendLayout();
            this.panelDoctorSave.SuspendLayout();
            this.panelMakeAnAppointment.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelPatientSave
            // 
            this.panelPatientSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.panelPatientSave.Controls.Add(this.textBox30);
            this.panelPatientSave.Controls.Add(this.button2);
            this.panelPatientSave.Controls.Add(this.textBox25);
            this.panelPatientSave.Controls.Add(this.textBox26);
            this.panelPatientSave.Controls.Add(this.textBox27);
            this.panelPatientSave.Controls.Add(this.textBox28);
            this.panelPatientSave.Controls.Add(this.textBox29);
            this.panelPatientSave.Controls.Add(this.textBox17);
            this.panelPatientSave.Controls.Add(this.textBox18);
            this.panelPatientSave.Controls.Add(this.textBox19);
            this.panelPatientSave.Controls.Add(this.textBox20);
            this.panelPatientSave.Controls.Add(this.textBox21);
            this.panelPatientSave.Controls.Add(this.textBox22);
            this.panelPatientSave.Controls.Add(this.textBox23);
            this.panelPatientSave.Controls.Add(this.textBox24);
            this.panelPatientSave.Location = new System.Drawing.Point(12, 15);
            this.panelPatientSave.Name = "panelPatientSave";
            this.panelPatientSave.Size = new System.Drawing.Size(316, 252);
            this.panelPatientSave.TabIndex = 22;
            // 
            // textBox30
            // 
            this.textBox30.Location = new System.Drawing.Point(128, 188);
            this.textBox30.Name = "textBox30";
            this.textBox30.PlaceholderText = "Состояние (заболевание)";
            this.textBox30.Size = new System.Drawing.Size(213, 23);
            this.textBox30.TabIndex = 33;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.White;
            this.button2.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Sylfaen", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button2.Location = new System.Drawing.Point(196, 218);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(145, 30);
            this.button2.TabIndex = 32;
            this.button2.Text = "Сохранить";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.SavePatient);
            // 
            // textBox25
            // 
            this.textBox25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.textBox25.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox25.Font = new System.Drawing.Font("Sylfaen", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox25.ForeColor = System.Drawing.Color.White;
            this.textBox25.Location = new System.Drawing.Point(18, 188);
            this.textBox25.Name = "textBox25";
            this.textBox25.ReadOnly = true;
            this.textBox25.Size = new System.Drawing.Size(104, 20);
            this.textBox25.TabIndex = 26;
            this.textBox25.Text = "Состояние ";
            this.textBox25.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox26
            // 
            this.textBox26.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox26.Location = new System.Drawing.Point(128, 159);
            this.textBox26.Name = "textBox26";
            this.textBox26.PlaceholderText = "Телефон";
            this.textBox26.Size = new System.Drawing.Size(213, 22);
            this.textBox26.TabIndex = 31;
            // 
            // textBox27
            // 
            this.textBox27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.textBox27.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox27.Font = new System.Drawing.Font("Sylfaen", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox27.ForeColor = System.Drawing.Color.White;
            this.textBox27.Location = new System.Drawing.Point(18, 130);
            this.textBox27.Name = "textBox27";
            this.textBox27.ReadOnly = true;
            this.textBox27.Size = new System.Drawing.Size(104, 20);
            this.textBox27.TabIndex = 27;
            this.textBox27.Text = "Пол (М/Ж)";
            this.textBox27.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox28
            // 
            this.textBox28.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox28.Location = new System.Drawing.Point(128, 130);
            this.textBox28.Name = "textBox28";
            this.textBox28.PlaceholderText = "Пол (М/Ж)";
            this.textBox28.Size = new System.Drawing.Size(213, 22);
            this.textBox28.TabIndex = 28;
            // 
            // textBox29
            // 
            this.textBox29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.textBox29.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox29.Font = new System.Drawing.Font("Sylfaen", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox29.ForeColor = System.Drawing.Color.White;
            this.textBox29.Location = new System.Drawing.Point(18, 159);
            this.textBox29.Name = "textBox29";
            this.textBox29.ReadOnly = true;
            this.textBox29.Size = new System.Drawing.Size(104, 20);
            this.textBox29.TabIndex = 30;
            this.textBox29.Text = "Телефон";
            this.textBox29.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox17
            // 
            this.textBox17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.textBox17.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox17.Font = new System.Drawing.Font("Sylfaen", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox17.ForeColor = System.Drawing.Color.White;
            this.textBox17.Location = new System.Drawing.Point(18, 14);
            this.textBox17.Name = "textBox17";
            this.textBox17.ReadOnly = true;
            this.textBox17.Size = new System.Drawing.Size(104, 20);
            this.textBox17.TabIndex = 18;
            this.textBox17.Text = "Фамилия";
            this.textBox17.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox18
            // 
            this.textBox18.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox18.Location = new System.Drawing.Point(128, 14);
            this.textBox18.Name = "textBox18";
            this.textBox18.PlaceholderText = "Фамилия";
            this.textBox18.Size = new System.Drawing.Size(213, 22);
            this.textBox18.TabIndex = 19;
            // 
            // textBox19
            // 
            this.textBox19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.textBox19.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox19.Font = new System.Drawing.Font("Sylfaen", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox19.ForeColor = System.Drawing.Color.White;
            this.textBox19.Location = new System.Drawing.Point(18, 43);
            this.textBox19.Name = "textBox19";
            this.textBox19.ReadOnly = true;
            this.textBox19.Size = new System.Drawing.Size(104, 20);
            this.textBox19.TabIndex = 20;
            this.textBox19.Text = "Имя";
            this.textBox19.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox20
            // 
            this.textBox20.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox20.Location = new System.Drawing.Point(128, 43);
            this.textBox20.Name = "textBox20";
            this.textBox20.PlaceholderText = "Имя";
            this.textBox20.Size = new System.Drawing.Size(213, 22);
            this.textBox20.TabIndex = 25;
            // 
            // textBox21
            // 
            this.textBox21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.textBox21.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox21.Font = new System.Drawing.Font("Sylfaen", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox21.ForeColor = System.Drawing.Color.White;
            this.textBox21.Location = new System.Drawing.Point(18, 72);
            this.textBox21.Name = "textBox21";
            this.textBox21.ReadOnly = true;
            this.textBox21.Size = new System.Drawing.Size(104, 20);
            this.textBox21.TabIndex = 21;
            this.textBox21.Text = "Отчество";
            this.textBox21.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox22
            // 
            this.textBox22.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox22.Location = new System.Drawing.Point(128, 73);
            this.textBox22.Name = "textBox22";
            this.textBox22.PlaceholderText = "Отчество";
            this.textBox22.Size = new System.Drawing.Size(213, 22);
            this.textBox22.TabIndex = 22;
            // 
            // textBox23
            // 
            this.textBox23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.textBox23.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox23.Font = new System.Drawing.Font("Sylfaen", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox23.ForeColor = System.Drawing.Color.White;
            this.textBox23.Location = new System.Drawing.Point(18, 101);
            this.textBox23.Name = "textBox23";
            this.textBox23.ReadOnly = true;
            this.textBox23.Size = new System.Drawing.Size(104, 20);
            this.textBox23.TabIndex = 24;
            this.textBox23.Text = "Дата рождения";
            this.textBox23.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox24
            // 
            this.textBox24.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox24.Location = new System.Drawing.Point(128, 101);
            this.textBox24.Name = "textBox24";
            this.textBox24.PlaceholderText = "Дата рождения";
            this.textBox24.Size = new System.Drawing.Size(213, 22);
            this.textBox24.TabIndex = 23;
            // 
            // panelServiceSave
            // 
            this.panelServiceSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.panelServiceSave.Controls.Add(this.button3);
            this.panelServiceSave.Controls.Add(this.textBox7);
            this.panelServiceSave.Controls.Add(this.textBox8);
            this.panelServiceSave.Controls.Add(this.textBox31);
            this.panelServiceSave.Controls.Add(this.textBox32);
            this.panelServiceSave.Controls.Add(this.textBox33);
            this.panelServiceSave.Controls.Add(this.textBox34);
            this.panelServiceSave.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.panelServiceSave.Location = new System.Drawing.Point(12, 200);
            this.panelServiceSave.Name = "panelServiceSave";
            this.panelServiceSave.Size = new System.Drawing.Size(315, 35);
            this.panelServiceSave.TabIndex = 23;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.White;
            this.button3.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.button3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.button3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Sylfaen", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button3.Location = new System.Drawing.Point(191, 144);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(145, 30);
            this.button3.TabIndex = 32;
            this.button3.Text = "Сохранить";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.SaveService);
            // 
            // textBox7
            // 
            this.textBox7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.textBox7.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox7.Font = new System.Drawing.Font("Sylfaen", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox7.ForeColor = System.Drawing.Color.White;
            this.textBox7.Location = new System.Drawing.Point(17, 57);
            this.textBox7.Name = "textBox7";
            this.textBox7.ReadOnly = true;
            this.textBox7.Size = new System.Drawing.Size(118, 20);
            this.textBox7.TabIndex = 26;
            this.textBox7.Text = "Название услуги";
            this.textBox7.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox8
            // 
            this.textBox8.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox8.Location = new System.Drawing.Point(140, 57);
            this.textBox8.Name = "textBox8";
            this.textBox8.PlaceholderText = "Название услуги";
            this.textBox8.Size = new System.Drawing.Size(198, 22);
            this.textBox8.TabIndex = 27;
            // 
            // textBox31
            // 
            this.textBox31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.textBox31.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox31.Font = new System.Drawing.Font("Sylfaen", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox31.ForeColor = System.Drawing.Color.White;
            this.textBox31.Location = new System.Drawing.Point(17, 86);
            this.textBox31.Name = "textBox31";
            this.textBox31.ReadOnly = true;
            this.textBox31.Size = new System.Drawing.Size(118, 20);
            this.textBox31.TabIndex = 28;
            this.textBox31.Text = "Специалист";
            this.textBox31.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox32
            // 
            this.textBox32.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox32.Location = new System.Drawing.Point(141, 87);
            this.textBox32.Name = "textBox32";
            this.textBox32.PlaceholderText = "Специалист";
            this.textBox32.Size = new System.Drawing.Size(197, 22);
            this.textBox32.TabIndex = 31;
            // 
            // textBox33
            // 
            this.textBox33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.textBox33.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox33.Font = new System.Drawing.Font("Sylfaen", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox33.ForeColor = System.Drawing.Color.White;
            this.textBox33.Location = new System.Drawing.Point(17, 115);
            this.textBox33.Name = "textBox33";
            this.textBox33.ReadOnly = true;
            this.textBox33.Size = new System.Drawing.Size(118, 20);
            this.textBox33.TabIndex = 29;
            this.textBox33.Text = "Цена";
            this.textBox33.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox34
            // 
            this.textBox34.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox34.Location = new System.Drawing.Point(140, 116);
            this.textBox34.Name = "textBox34";
            this.textBox34.PlaceholderText = "Цена, руб.";
            this.textBox34.Size = new System.Drawing.Size(198, 22);
            this.textBox34.TabIndex = 30;
            // 
            // panelDoctorSave
            // 
            this.panelDoctorSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.panelDoctorSave.Controls.Add(this.textBox16);
            this.panelDoctorSave.Controls.Add(this.button4);
            this.panelDoctorSave.Controls.Add(this.textBox35);
            this.panelDoctorSave.Controls.Add(this.textBox36);
            this.panelDoctorSave.Controls.Add(this.textBox1);
            this.panelDoctorSave.Controls.Add(this.textBox2);
            this.panelDoctorSave.Controls.Add(this.textBox3);
            this.panelDoctorSave.Controls.Add(this.textBox4);
            this.panelDoctorSave.Controls.Add(this.textBox5);
            this.panelDoctorSave.Controls.Add(this.textBox6);
            this.panelDoctorSave.Controls.Add(this.textBox46);
            this.panelDoctorSave.Controls.Add(this.textBox9);
            this.panelDoctorSave.Controls.Add(this.textBox45);
            this.panelDoctorSave.Controls.Add(this.textBox10);
            this.panelDoctorSave.Controls.Add(this.textBox11);
            this.panelDoctorSave.Controls.Add(this.textBox12);
            this.panelDoctorSave.Controls.Add(this.textBox13);
            this.panelDoctorSave.Controls.Add(this.textBox14);
            this.panelDoctorSave.Controls.Add(this.textBox15);
            this.panelDoctorSave.Location = new System.Drawing.Point(12, 250);
            this.panelDoctorSave.Name = "panelDoctorSave";
            this.panelDoctorSave.Size = new System.Drawing.Size(316, 44);
            this.panelDoctorSave.TabIndex = 25;
            this.panelDoctorSave.Paint += new System.Windows.Forms.PaintEventHandler(this.panelDoctorSave_Paint);
            // 
            // textBox16
            // 
            this.textBox16.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox16.Location = new System.Drawing.Point(136, 105);
            this.textBox16.Name = "textBox16";
            this.textBox16.PlaceholderText = "Дата рождения";
            this.textBox16.Size = new System.Drawing.Size(207, 22);
            this.textBox16.TabIndex = 36;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.White;
            this.button4.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.button4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.button4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Sylfaen", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button4.Location = new System.Drawing.Point(198, 246);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(145, 30);
            this.button4.TabIndex = 35;
            this.button4.Text = "Сохранить";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.ButtonSaveDoctor);
            // 
            // textBox35
            // 
            this.textBox35.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.textBox35.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox35.Font = new System.Drawing.Font("Sylfaen", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox35.ForeColor = System.Drawing.Color.White;
            this.textBox35.Location = new System.Drawing.Point(14, 192);
            this.textBox35.Name = "textBox35";
            this.textBox35.ReadOnly = true;
            this.textBox35.Size = new System.Drawing.Size(116, 20);
            this.textBox35.TabIndex = 33;
            this.textBox35.Text = "Номер кабинета";
            this.textBox35.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox36
            // 
            this.textBox36.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox36.Location = new System.Drawing.Point(136, 218);
            this.textBox36.Name = "textBox36";
            this.textBox36.PlaceholderText = "Специальность";
            this.textBox36.Size = new System.Drawing.Size(207, 22);
            this.textBox36.TabIndex = 34;
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Font = new System.Drawing.Font("Sylfaen", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox1.ForeColor = System.Drawing.Color.White;
            this.textBox1.Location = new System.Drawing.Point(14, 218);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(116, 20);
            this.textBox1.TabIndex = 26;
            this.textBox1.Text = "Специальность";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox2.Location = new System.Drawing.Point(136, 163);
            this.textBox2.Name = "textBox2";
            this.textBox2.PlaceholderText = "Телефон";
            this.textBox2.Size = new System.Drawing.Size(207, 22);
            this.textBox2.TabIndex = 31;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.textBox3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox3.Font = new System.Drawing.Font("Sylfaen", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox3.ForeColor = System.Drawing.Color.White;
            this.textBox3.Location = new System.Drawing.Point(14, 134);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(116, 20);
            this.textBox3.TabIndex = 27;
            this.textBox3.Text = "Пол (М/Ж)";
            this.textBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox4.Location = new System.Drawing.Point(136, 134);
            this.textBox4.Name = "textBox4";
            this.textBox4.PlaceholderText = "Пол (М/Ж)";
            this.textBox4.Size = new System.Drawing.Size(207, 22);
            this.textBox4.TabIndex = 28;
            // 
            // textBox5
            // 
            this.textBox5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.textBox5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox5.Font = new System.Drawing.Font("Sylfaen", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox5.ForeColor = System.Drawing.Color.White;
            this.textBox5.Location = new System.Drawing.Point(14, 163);
            this.textBox5.Name = "textBox5";
            this.textBox5.ReadOnly = true;
            this.textBox5.Size = new System.Drawing.Size(116, 20);
            this.textBox5.TabIndex = 30;
            this.textBox5.Text = "Телефон";
            this.textBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox6
            // 
            this.textBox6.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox6.Location = new System.Drawing.Point(136, 192);
            this.textBox6.Name = "textBox6";
            this.textBox6.PlaceholderText = "Номер кабинета";
            this.textBox6.Size = new System.Drawing.Size(207, 22);
            this.textBox6.TabIndex = 29;
            // 
            // textBox46
            // 
            this.textBox46.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.textBox46.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox46.Font = new System.Drawing.Font("Sylfaen", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox46.ForeColor = System.Drawing.Color.White;
            this.textBox46.Location = new System.Drawing.Point(18, 15);
            this.textBox46.Name = "textBox46";
            this.textBox46.ReadOnly = true;
            this.textBox46.Size = new System.Drawing.Size(112, 20);
            this.textBox46.TabIndex = 18;
            this.textBox46.Text = "Фамилия";
            this.textBox46.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox9
            // 
            this.textBox9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.textBox9.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox9.Font = new System.Drawing.Font("Sylfaen", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox9.ForeColor = System.Drawing.Color.White;
            this.textBox9.Location = new System.Drawing.Point(14, 15);
            this.textBox9.Name = "textBox9";
            this.textBox9.ReadOnly = true;
            this.textBox9.Size = new System.Drawing.Size(116, 20);
            this.textBox9.TabIndex = 18;
            this.textBox9.Text = "Фамилия";
            this.textBox9.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox45
            // 
            this.textBox45.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.textBox45.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox45.Font = new System.Drawing.Font("Sylfaen", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox45.ForeColor = System.Drawing.Color.White;
            this.textBox45.Location = new System.Drawing.Point(18, 44);
            this.textBox45.Name = "textBox45";
            this.textBox45.ReadOnly = true;
            this.textBox45.Size = new System.Drawing.Size(112, 20);
            this.textBox45.TabIndex = 20;
            this.textBox45.Text = "Имя";
            this.textBox45.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox10
            // 
            this.textBox10.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox10.Location = new System.Drawing.Point(136, 15);
            this.textBox10.Name = "textBox10";
            this.textBox10.PlaceholderText = "Фамилия";
            this.textBox10.Size = new System.Drawing.Size(207, 22);
            this.textBox10.TabIndex = 19;
            // 
            // textBox11
            // 
            this.textBox11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.textBox11.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox11.Font = new System.Drawing.Font("Sylfaen", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox11.ForeColor = System.Drawing.Color.White;
            this.textBox11.Location = new System.Drawing.Point(14, 44);
            this.textBox11.Name = "textBox11";
            this.textBox11.ReadOnly = true;
            this.textBox11.Size = new System.Drawing.Size(116, 20);
            this.textBox11.TabIndex = 20;
            this.textBox11.Text = "Имя";
            this.textBox11.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox12
            // 
            this.textBox12.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox12.Location = new System.Drawing.Point(136, 44);
            this.textBox12.Name = "textBox12";
            this.textBox12.PlaceholderText = "Имя";
            this.textBox12.Size = new System.Drawing.Size(207, 22);
            this.textBox12.TabIndex = 25;
            // 
            // textBox13
            // 
            this.textBox13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.textBox13.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox13.Font = new System.Drawing.Font("Sylfaen", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox13.ForeColor = System.Drawing.Color.White;
            this.textBox13.Location = new System.Drawing.Point(14, 73);
            this.textBox13.Name = "textBox13";
            this.textBox13.ReadOnly = true;
            this.textBox13.Size = new System.Drawing.Size(116, 20);
            this.textBox13.TabIndex = 21;
            this.textBox13.Text = "Отчество";
            this.textBox13.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox14
            // 
            this.textBox14.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox14.Location = new System.Drawing.Point(136, 73);
            this.textBox14.Name = "textBox14";
            this.textBox14.PlaceholderText = "Отчество";
            this.textBox14.Size = new System.Drawing.Size(207, 22);
            this.textBox14.TabIndex = 22;
            // 
            // textBox15
            // 
            this.textBox15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.textBox15.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox15.Font = new System.Drawing.Font("Sylfaen", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox15.ForeColor = System.Drawing.Color.White;
            this.textBox15.Location = new System.Drawing.Point(14, 105);
            this.textBox15.Name = "textBox15";
            this.textBox15.ReadOnly = true;
            this.textBox15.Size = new System.Drawing.Size(116, 20);
            this.textBox15.TabIndex = 24;
            this.textBox15.Text = "Дата рождения";
            this.textBox15.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // panelMakeAnAppointment
            // 
            this.panelMakeAnAppointment.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.panelMakeAnAppointment.Controls.Add(this.textBox43);
            this.panelMakeAnAppointment.Controls.Add(this.button6);
            this.panelMakeAnAppointment.Controls.Add(this.textBox42);
            this.panelMakeAnAppointment.Controls.Add(this.button5);
            this.panelMakeAnAppointment.Controls.Add(this.textBox41);
            this.panelMakeAnAppointment.Controls.Add(this.textBox40);
            this.panelMakeAnAppointment.Controls.Add(this.textBox39);
            this.panelMakeAnAppointment.Controls.Add(this.comboBoxService);
            this.panelMakeAnAppointment.Controls.Add(this.textBox38);
            this.panelMakeAnAppointment.Controls.Add(this.comboBoxDoctor);
            this.panelMakeAnAppointment.Controls.Add(this.button1);
            this.panelMakeAnAppointment.Controls.Add(this.textBox37);
            this.panelMakeAnAppointment.Controls.Add(this.comboBoxPatient);
            this.panelMakeAnAppointment.Location = new System.Drawing.Point(12, 12);
            this.panelMakeAnAppointment.Name = "panelMakeAnAppointment";
            this.panelMakeAnAppointment.Size = new System.Drawing.Size(315, 47);
            this.panelMakeAnAppointment.TabIndex = 26;
            this.panelMakeAnAppointment.Paint += new System.Windows.Forms.PaintEventHandler(this.panelMakeAnAppointment_Paint);
            // 
            // textBox43
            // 
            this.textBox43.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.textBox43.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox43.Font = new System.Drawing.Font("Sylfaen", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox43.ForeColor = System.Drawing.Color.White;
            this.textBox43.Location = new System.Drawing.Point(20, 174);
            this.textBox43.Name = "textBox43";
            this.textBox43.ReadOnly = true;
            this.textBox43.Size = new System.Drawing.Size(88, 20);
            this.textBox43.TabIndex = 12;
            this.textBox43.Text = "Специалист";
            this.textBox43.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.White;
            this.button6.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.button6.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.button6.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.button6.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Sylfaen", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button6.Location = new System.Drawing.Point(150, 137);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(184, 30);
            this.button6.TabIndex = 11;
            this.button6.Text = "Подобрать специалиста";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // textBox42
            // 
            this.textBox42.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox42.Location = new System.Drawing.Point(114, 174);
            this.textBox42.Name = "textBox42";
            this.textBox42.Size = new System.Drawing.Size(220, 22);
            this.textBox42.TabIndex = 10;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.White;
            this.button5.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.button5.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.button5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.button5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Sylfaen", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button5.Location = new System.Drawing.Point(150, 45);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(184, 30);
            this.button5.TabIndex = 9;
            this.button5.Text = "Показать состояние ";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // textBox41
            // 
            this.textBox41.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox41.Location = new System.Drawing.Point(114, 81);
            this.textBox41.Name = "textBox41";
            this.textBox41.Size = new System.Drawing.Size(220, 22);
            this.textBox41.TabIndex = 8;
            // 
            // textBox40
            // 
            this.textBox40.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.textBox40.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox40.Font = new System.Drawing.Font("Sylfaen", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox40.ForeColor = System.Drawing.Color.White;
            this.textBox40.Location = new System.Drawing.Point(20, 81);
            this.textBox40.Name = "textBox40";
            this.textBox40.ReadOnly = true;
            this.textBox40.Size = new System.Drawing.Size(88, 20);
            this.textBox40.TabIndex = 7;
            this.textBox40.Text = "Состояние";
            this.textBox40.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox39
            // 
            this.textBox39.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.textBox39.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox39.Font = new System.Drawing.Font("Sylfaen", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox39.ForeColor = System.Drawing.Color.White;
            this.textBox39.Location = new System.Drawing.Point(20, 203);
            this.textBox39.Name = "textBox39";
            this.textBox39.ReadOnly = true;
            this.textBox39.Size = new System.Drawing.Size(88, 20);
            this.textBox39.TabIndex = 6;
            this.textBox39.Text = "Врач";
            this.textBox39.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // comboBoxService
            // 
            this.comboBoxService.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.comboBoxService.FormattingEnabled = true;
            this.comboBoxService.Location = new System.Drawing.Point(114, 110);
            this.comboBoxService.Name = "comboBoxService";
            this.comboBoxService.Size = new System.Drawing.Size(220, 22);
            this.comboBoxService.TabIndex = 5;
            // 
            // textBox38
            // 
            this.textBox38.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.textBox38.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox38.Font = new System.Drawing.Font("Sylfaen", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox38.ForeColor = System.Drawing.Color.White;
            this.textBox38.Location = new System.Drawing.Point(20, 110);
            this.textBox38.Name = "textBox38";
            this.textBox38.ReadOnly = true;
            this.textBox38.Size = new System.Drawing.Size(88, 20);
            this.textBox38.TabIndex = 4;
            this.textBox38.Text = "Услуга";
            this.textBox38.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // comboBoxDoctor
            // 
            this.comboBoxDoctor.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.comboBoxDoctor.FormattingEnabled = true;
            this.comboBoxDoctor.Location = new System.Drawing.Point(115, 203);
            this.comboBoxDoctor.Name = "comboBoxDoctor";
            this.comboBoxDoctor.Size = new System.Drawing.Size(220, 22);
            this.comboBoxDoctor.TabIndex = 3;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.White;
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.button1.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Sylfaen", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button1.Location = new System.Drawing.Point(150, 231);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(184, 30);
            this.button1.TabIndex = 2;
            this.button1.Text = "Записать на прием";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.ButtonMakeAnAppointment);
            // 
            // textBox37
            // 
            this.textBox37.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.textBox37.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox37.Font = new System.Drawing.Font("Sylfaen", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox37.ForeColor = System.Drawing.Color.White;
            this.textBox37.Location = new System.Drawing.Point(20, 17);
            this.textBox37.Name = "textBox37";
            this.textBox37.ReadOnly = true;
            this.textBox37.Size = new System.Drawing.Size(88, 20);
            this.textBox37.TabIndex = 1;
            this.textBox37.Text = "Пациент";
            this.textBox37.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // comboBoxPatient
            // 
            this.comboBoxPatient.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.comboBoxPatient.FormattingEnabled = true;
            this.comboBoxPatient.Location = new System.Drawing.Point(114, 17);
            this.comboBoxPatient.Name = "comboBoxPatient";
            this.comboBoxPatient.Size = new System.Drawing.Size(220, 22);
            this.comboBoxPatient.TabIndex = 0;
            // 
            // backgroundWorker1
            // 
            this.backgroundWorker1.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundWorker1_DoWork);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(339, 279);
            this.Controls.Add(this.panelMakeAnAppointment);
            this.Controls.Add(this.panelDoctorSave);
            this.Controls.Add(this.panelServiceSave);
            this.Controls.Add(this.panelPatientSave);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form2";
            this.RightToLeftLayout = true;
            this.Text = "Dental Clinic";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.panelPatientSave.ResumeLayout(false);
            this.panelPatientSave.PerformLayout();
            this.panelServiceSave.ResumeLayout(false);
            this.panelServiceSave.PerformLayout();
            this.panelDoctorSave.ResumeLayout(false);
            this.panelDoctorSave.PerformLayout();
            this.panelMakeAnAppointment.ResumeLayout(false);
            this.panelMakeAnAppointment.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private Panel panelPatientSave;
        private TextBox textBox25;
        private TextBox textBox26;
        private TextBox textBox27;
        private TextBox textBox28;
        private TextBox textBox29;
        private TextBox textBox17;
        private TextBox textBox18;
        private TextBox textBox19;
        private TextBox textBox20;
        private TextBox textBox21;
        private TextBox textBox22;
        private TextBox textBox23;
        private TextBox textBox24;
        private Button button2;
        private Panel panelServiceSave;
        private Button button3;
        private TextBox textBox7;
        private TextBox textBox8;
        private TextBox textBox31;
        private TextBox textBox32;
        private TextBox textBox33;
        private TextBox textBox34;
        private Panel panelDoctorSave;
        private TextBox textBox1;
        private TextBox textBox2;
        private TextBox textBox3;
        private TextBox textBox4;
        private TextBox textBox6;
        private TextBox textBox9;
        private TextBox textBox11;
        private TextBox textBox12;
        private TextBox textBox13;
        private TextBox textBox14;
        private TextBox textBox15;
        private TextBox textBox36;
        private Button button4;
        private Panel panelMakeAnAppointment;
        private TextBox textBox38;
        private ComboBox comboBoxDoctor;
        private Button button1;
        private TextBox textBox37;
        private ComboBox comboBoxPatient;
        private TextBox textBox40;
        private TextBox textBox39;
        private ComboBox comboBoxService;
        private TextBox textBox41;
        private Button button5;
        private Button button6;
        private TextBox textBox42;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private TextBox textBox16;
        private TextBox textBox46;
        private TextBox textBox45;
        private TextBox textBox35;
        private TextBox textBox5;
        private TextBox textBox10;
        private TextBox textBox43;
        private TextBox textBox30;
    }
}